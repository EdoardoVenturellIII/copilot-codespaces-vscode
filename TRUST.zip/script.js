document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Messaggio inviato con successo!");
});